// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.PackageManager.UI.IBaseOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class IBaseOperation : ReflectiveClass
	{
		private ReflectiveEvent event_OnOperationError;
		private ReflectiveEvent event_OnOperationFinalized;
		private ReflectiveProperty<bool> property_IsCompleted;
		private ReflectiveMethod method_Cancel_1;
		public IBaseOperation(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public IBaseOperation(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			event_OnOperationError = CreateEvent("OnOperationError", BindingFlags.Instance | BindingFlags.Public);
			event_OnOperationFinalized = CreateEvent("OnOperationFinalized", BindingFlags.Instance | BindingFlags.Public);
			property_IsCompleted = CreateProperty<bool>("IsCompleted", BindingFlags.Instance | BindingFlags.Public);
			method_Cancel_1 = CreateMethod("Cancel", BindingFlags.Instance | BindingFlags.Public, null);
		}
		partial void Initialize();
		/// <summary>
		/// Event type: System.Action<Error>
		/// </summary>
		/// <returns>Delegate to be used for unsubscribing</returns>
		public Delegate SubscribeToOnOperationError(Delegate @delegate)
		{
			return event_OnOperationError.Subscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<Error>
		/// </summary>
		public void UnsubscribeFromOnOperationError(Delegate @delegate)
		{
			event_OnOperationError.Unsubscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action
		/// </summary>
		/// <returns>Delegate to be used for unsubscribing</returns>
		public Delegate SubscribeToOnOperationFinalized(Delegate @delegate)
		{
			return event_OnOperationFinalized.Subscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action
		/// </summary>
		public void UnsubscribeFromOnOperationFinalized(Delegate @delegate)
		{
			event_OnOperationFinalized.Unsubscribe(@delegate);
		}
		public bool IsCompleted
		{
			get => property_IsCompleted.GetValue();
		}
		public void Cancel()
		{
			method_Cancel_1.Invoke();
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.PackageManager.UI.IBaseOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
