// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.PackageManager.UI.PackageAddFromUrlField, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.UI;
using UnityEngine;
using UnityEngine.UIElements;
using UnityEngine.UIElements.StyleSheets;
using UnityEngine.Yoga;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class PackageAddFromUrlField : ReflectiveClass
	{
		private ReflectiveField<string> field_urlText;
		private ReflectiveField<VisualElement> field_root;
		private ReflectiveProperty property_Cache;
		private ReflectiveProperty<VisualElement> property_AddFromUrlFieldContainer;
		private ReflectiveProperty<TextField> property_UrlTextField;
		private ReflectiveProperty<Button> property_AddButton;
		private ReflectiveMethod method_OnUrlTextFieldChange_1;
		private ReflectiveMethod method_OnUrlTextFieldFocus_1;
		private ReflectiveMethod method_OnUrlTextFieldFocusOut_1;
		private ReflectiveMethod method_OnContainerFocus_1;
		private ReflectiveMethod method_OnContainerFocusOut_1;
		private ReflectiveMethod method_OnEnterPanel_1;
		private ReflectiveMethod method_OnLeavePanel_1;
		private ReflectiveMethod method_OnKeyDownShortcut_1;
		private ReflectiveMethod method_OnAddButtonClick_1;
		private ReflectiveMethod method_Hide_1;
		private ReflectiveMethod method_Show_1;
		private ReflectiveMethod method_Reset_1;
		public PackageAddFromUrlField(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public PackageAddFromUrlField(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			field_urlText = CreateField<string>("urlText", BindingFlags.Instance | BindingFlags.NonPublic);
			field_root = CreateField<VisualElement>("root", BindingFlags.Instance | BindingFlags.NonPublic);
			property_Cache = CreateProperty("Cache", BindingFlags.Instance | BindingFlags.NonPublic);
			property_AddFromUrlFieldContainer = CreateProperty<VisualElement>("AddFromUrlFieldContainer", BindingFlags.Instance | BindingFlags.NonPublic);
			property_UrlTextField = CreateProperty<TextField>("UrlTextField", BindingFlags.Instance | BindingFlags.NonPublic);
			property_AddButton = CreateProperty<Button>("AddButton", BindingFlags.Instance | BindingFlags.NonPublic);
			method_OnUrlTextFieldChange_1 = CreateMethod("OnUrlTextFieldChange", BindingFlags.Instance | BindingFlags.NonPublic, typeof(ChangeEvent<string>));
			method_OnUrlTextFieldFocus_1 = CreateMethod("OnUrlTextFieldFocus", BindingFlags.Instance | BindingFlags.NonPublic, typeof(FocusEvent));
			method_OnUrlTextFieldFocusOut_1 = CreateMethod("OnUrlTextFieldFocusOut", BindingFlags.Instance | BindingFlags.NonPublic, typeof(FocusOutEvent));
			method_OnContainerFocus_1 = CreateMethod("OnContainerFocus", BindingFlags.Instance | BindingFlags.NonPublic, typeof(FocusEvent));
			method_OnContainerFocusOut_1 = CreateMethod("OnContainerFocusOut", BindingFlags.Instance | BindingFlags.NonPublic, typeof(FocusOutEvent));
			method_OnEnterPanel_1 = CreateMethod("OnEnterPanel", BindingFlags.Instance | BindingFlags.NonPublic, typeof(AttachToPanelEvent));
			method_OnLeavePanel_1 = CreateMethod("OnLeavePanel", BindingFlags.Instance | BindingFlags.NonPublic, typeof(DetachFromPanelEvent));
			method_OnKeyDownShortcut_1 = CreateMethod("OnKeyDownShortcut", BindingFlags.Instance | BindingFlags.NonPublic, typeof(KeyDownEvent));
			method_OnAddButtonClick_1 = CreateMethod("OnAddButtonClick", BindingFlags.Instance | BindingFlags.NonPublic, null);
			method_Hide_1 = CreateMethod("Hide", BindingFlags.Instance | BindingFlags.NonPublic, null);
			method_Show_1 = CreateMethod("Show", BindingFlags.Instance | BindingFlags.NonPublic, typeof(bool));
			method_Reset_1 = CreateMethod("Reset", BindingFlags.Instance | BindingFlags.NonPublic, null);
		}
		partial void Initialize();
		public string urlText
		{
			get => field_urlText.GetValue();
			set => field_urlText.SetValue(value);
		}
		public VisualElement root
		{
			get => field_root.GetValue();
			set => field_root.SetValue(value);
		}
		public VisualElementCache Cache
		{
			get
			{
				object _temp = property_Cache.GetValue();
				return _temp == null ? null : new VisualElementCache(_temp);
			}
			set => property_Cache.SetValue(value.Instance);
		}
		public VisualElement AddFromUrlFieldContainer
		{
			get => property_AddFromUrlFieldContainer.GetValue();
		}
		public TextField UrlTextField
		{
			get => property_UrlTextField.GetValue();
		}
		public Button AddButton
		{
			get => property_AddButton.GetValue();
		}
		public void OnUrlTextFieldChange(ChangeEvent<string> evt)
		{
			method_OnUrlTextFieldChange_1.Invoke(evt);
		}
		public void OnUrlTextFieldFocus(FocusEvent evt)
		{
			method_OnUrlTextFieldFocus_1.Invoke(evt);
		}
		public void OnUrlTextFieldFocusOut(FocusOutEvent evt)
		{
			method_OnUrlTextFieldFocusOut_1.Invoke(evt);
		}
		public void OnContainerFocus(FocusEvent evt)
		{
			method_OnContainerFocus_1.Invoke(evt);
		}
		public void OnContainerFocusOut(FocusOutEvent evt)
		{
			method_OnContainerFocusOut_1.Invoke(evt);
		}
		public void OnEnterPanel(AttachToPanelEvent evt)
		{
			method_OnEnterPanel_1.Invoke(evt);
		}
		public void OnLeavePanel(DetachFromPanelEvent evt)
		{
			method_OnLeavePanel_1.Invoke(evt);
		}
		public void OnKeyDownShortcut(KeyDownEvent evt)
		{
			method_OnKeyDownShortcut_1.Invoke(evt);
		}
		public void OnAddButtonClick()
		{
			method_OnAddButtonClick_1.Invoke();
		}
		public void Hide()
		{
			method_Hide_1.Invoke();
		}
		public void Show(bool reset)
		{
			method_Show_1.Invoke(reset);
		}
		public void Reset()
		{
			method_Reset_1.Invoke();
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.PackageManager.UI.PackageAddFromUrlField, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
