// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.PackageManager.UI.ISearchOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
using System.Collections.Generic;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class ISearchOperation : ReflectiveClass
	{
		private ReflectiveMethod method_GetAllPackageAsync_1;
		public ISearchOperation(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public ISearchOperation(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			method_GetAllPackageAsync_1 = CreateMethod("GetAllPackageAsync", BindingFlags.Instance | BindingFlags.Public, typeof(string),typeof(Action<IEnumerable<PackageInfo>>),typeof(Action<Error>));
		}
		partial void Initialize();
		public void GetAllPackageAsync(string packageNameOrId,Action<IEnumerable<PackageInfo>> doneCallbackAction,Action<Error> errorCallbackAction)
		{
			method_GetAllPackageAsync_1.Invoke(packageNameOrId,doneCallbackAction,errorCallbackAction);
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.PackageManager.UI.ISearchOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
