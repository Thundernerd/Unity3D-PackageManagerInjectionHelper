// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.GenericMenu+MenuFunction, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class MenuFunction : ReflectiveClass
	{
		private ReflectiveMethod method_Invoke_1;
		private ReflectiveMethod method_BeginInvoke_1;
		private ReflectiveMethod method_EndInvoke_1;
		public MenuFunction(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public MenuFunction(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			method_Invoke_1 = CreateMethod("Invoke", BindingFlags.Instance | BindingFlags.Public, null);
			method_BeginInvoke_1 = CreateMethod("BeginInvoke", BindingFlags.Instance | BindingFlags.Public, typeof(AsyncCallback),typeof(Object));
			method_EndInvoke_1 = CreateMethod("EndInvoke", BindingFlags.Instance | BindingFlags.Public, typeof(IAsyncResult));
		}
		partial void Initialize();
		public void Invoke()
		{
			method_Invoke_1.Invoke();
		}
		public IAsyncResult BeginInvoke(AsyncCallback callback,Object @object)
		{
			return (IAsyncResult) method_BeginInvoke_1.Invoke(callback,@object);
		}
		public void EndInvoke(IAsyncResult result)
		{
			method_EndInvoke_1.Invoke(result);
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.GenericMenu+MenuFunction, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
