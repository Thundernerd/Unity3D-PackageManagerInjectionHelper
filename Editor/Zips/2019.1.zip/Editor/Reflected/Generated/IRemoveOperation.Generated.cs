// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.PackageManager.UI.IRemoveOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class IRemoveOperation : ReflectiveClass
	{
		private ReflectiveEvent event_OnOperationSuccess;
		private ReflectiveMethod method_RemovePackageAsync_1;
		public IRemoveOperation(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public IRemoveOperation(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			event_OnOperationSuccess = CreateEvent("OnOperationSuccess", BindingFlags.Instance | BindingFlags.Public);
			method_RemovePackageAsync_1 = CreateMethod("RemovePackageAsync", BindingFlags.Instance | BindingFlags.Public, typeof(PackageInfo),typeof(Action<PackageInfo>),typeof(Action<Error>));
		}
		partial void Initialize();
		/// <summary>
		/// Event type: System.Action<PackageInfo>
		/// </summary>
		/// <returns>Delegate to be used for unsubscribing</returns>
		public Delegate SubscribeToOnOperationSuccess(Delegate @delegate)
		{
			return event_OnOperationSuccess.Subscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<PackageInfo>
		/// </summary>
		public void UnsubscribeFromOnOperationSuccess(Delegate @delegate)
		{
			event_OnOperationSuccess.Unsubscribe(@delegate);
		}
		public void RemovePackageAsync(PackageInfo package,Action<PackageInfo> doneCallbackAction,Action<Error> errorCallbackAction)
		{
			method_RemovePackageAsync_1.Invoke(package,doneCallbackAction,errorCallbackAction);
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.PackageManager.UI.IRemoveOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
