// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.PackageManager.UI.IAddOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.UI;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class IAddOperation : ReflectiveClass
	{
		private ReflectiveEvent event_OnOperationSuccess;
		private ReflectiveProperty property_PackageInfo;
		private ReflectiveMethod method_AddPackageAsync_1;
		private ReflectiveMethod method_AddPackageAsync_2;
		public IAddOperation(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public IAddOperation(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			event_OnOperationSuccess = CreateEvent("OnOperationSuccess", BindingFlags.Instance | BindingFlags.Public);
			property_PackageInfo = CreateProperty("PackageInfo", BindingFlags.Instance | BindingFlags.Public);
			method_AddPackageAsync_1 = CreateMethod("AddPackageAsync", BindingFlags.Instance | BindingFlags.Public, typeof(PackageInfo),typeof(Action<PackageInfo>),typeof(Action<Error>));
			method_AddPackageAsync_2 = CreateMethod("AddPackageAsync", BindingFlags.Instance | BindingFlags.Public, typeof(string),typeof(Action<PackageInfo>),typeof(Action<Error>));
		}
		partial void Initialize();
		/// <summary>
		/// Event type: System.Action<PackageInfo>
		/// </summary>
		/// <returns>Delegate to be used for unsubscribing</returns>
		public Delegate SubscribeToOnOperationSuccess(Delegate @delegate)
		{
			return event_OnOperationSuccess.Subscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<PackageInfo>
		/// </summary>
		public void UnsubscribeFromOnOperationSuccess(Delegate @delegate)
		{
			event_OnOperationSuccess.Unsubscribe(@delegate);
		}
		public PackageInfo PackageInfo
		{
			get
			{
				object _temp = property_PackageInfo.GetValue();
				return _temp == null ? null : new PackageInfo(_temp);
			}
		}
		public void AddPackageAsync(PackageInfo packageInfo,Action<PackageInfo> doneCallbackAction,Action<Error> errorCallbackAction)
		{
			method_AddPackageAsync_1.Invoke(packageInfo,doneCallbackAction,errorCallbackAction);
		}
		public void AddPackageAsync(string packageId,Action<PackageInfo> doneCallbackAction,Action<Error> errorCallbackAction)
		{
			method_AddPackageAsync_2.Invoke(packageId,doneCallbackAction,errorCallbackAction);
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.PackageManager.UI.IAddOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
