// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.PackageManager.UI.PackageCollection, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.UI;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class PackageCollection : ReflectiveClass
	{
		private ReflectiveEvent event_OnPackagesChanged;
		private ReflectiveEvent event_OnFilterChanged;
		private ReflectiveEvent event_OnLatestPackageInfoFetched;
		private ReflectiveEvent event_OnUpdateTimeChange;
		private ReflectiveField field_EmbdeddedVersion;
		private ReflectiveField field_LocalVersion;
		private ReflectiveField field_OnPackagesChanged;
		private ReflectiveField field_OnFilterChanged;
		private ReflectiveField field_OnLatestPackageInfoFetched;
		private ReflectiveField<Action<string>> field_OnUpdateTimeChange;
		private ReflectiveField field_projectDependencies;
		private ReflectiveField field_packages;
		private ReflectiveField field_latestInfos;
		private ReflectiveField field_filter;
		private ReflectiveField<string> field_lastUpdateTime;
		private ReflectiveField field_listPackagesOffline;
		private ReflectiveField field_listPackages;
		private ReflectiveField field_searchPackages;
		private ReflectiveField field_latestInfoListCache;
		private ReflectiveField field_packageErrors;
		private ReflectiveField<int> field_listPackagesVersion;
		private ReflectiveField<int> field_listPackagesOfflineVersion;
		private ReflectiveField<bool> field_searchOperationOngoing;
		private ReflectiveField<bool> field_listOperationOngoing;
		private ReflectiveField<bool> field_listOperationOfflineOngoing;
		private ReflectiveField field_listOperationOffline;
		private ReflectiveField field_listOperation;
		private ReflectiveField field_searchOperation;
		private ReflectiveField field_SearchSignal;
		private ReflectiveField field_ListSignal;
		private ReflectiveProperty property_ProjectDependencies;
		private ReflectiveProperty property_Filter;
		private ReflectiveProperty property_CompletePackageInfosList;
		private ReflectiveProperty property_LatestListPackages;
		private ReflectiveProperty property_LatestSearchPackages;
		private ReflectiveMethod method_GetLatestInfoInCache_1;
		private ReflectiveMethod method_UpdateLatestInfoCache_1;
		private ReflectiveMethod method_SetFilter_1;
		private ReflectiveMethod method_UpdatePackageCollection_1;
		private ReflectiveMethod method_TriggerPackagesChanged_1;
		private ReflectiveMethod method_FetchListOfflineCache_1;
		private ReflectiveMethod method_FetchListCache_1;
		private ReflectiveMethod method_FetchSearchCache_1;
		private ReflectiveMethod method_NeedsFetchLatest_1;
		private ReflectiveMethod method_FetchLatestPackageInfo_1;
		private ReflectiveMethod method_UpdateListPackageInfosOffline_1;
		private ReflectiveMethod method_UpdateListPackageInfos_1;
		private ReflectiveMethod method_UpdateSearchPackageInfos_1;
		private ReflectiveMethod method_OrderedPackages_1;
		private ReflectiveMethod method_GetPackageByName_1;
		private ReflectiveMethod method_GetPackage_1;
		private ReflectiveMethod method_GetPackageVersion_1;
		private ReflectiveMethod method_GetPackageVersion_2;
		private ReflectiveMethod method_GetPackageError_1;
		private ReflectiveMethod method_AddPackageError_1;
		private ReflectiveMethod method_RemovePackageErrors_1;
		private ReflectiveMethod method_RebuildPackageDictionary_1;
		private ReflectiveMethod method_RebuildDependenciesDictionnary_1;
		public PackageCollection(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public PackageCollection(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			event_OnPackagesChanged = CreateEvent("OnPackagesChanged", BindingFlags.Instance | BindingFlags.Public);
			event_OnFilterChanged = CreateEvent("OnFilterChanged", BindingFlags.Instance | BindingFlags.Public);
			event_OnLatestPackageInfoFetched = CreateEvent("OnLatestPackageInfoFetched", BindingFlags.Instance | BindingFlags.Public);
			event_OnUpdateTimeChange = CreateEvent("OnUpdateTimeChange", BindingFlags.Instance | BindingFlags.Public);
			field_EmbdeddedVersion = CreateField("EmbdeddedVersion", BindingFlags.Static | BindingFlags.Public);
			field_LocalVersion = CreateField("LocalVersion", BindingFlags.Static | BindingFlags.Public);
			field_OnPackagesChanged = CreateField("OnPackagesChanged", BindingFlags.Instance | BindingFlags.NonPublic);
			field_OnFilterChanged = CreateField("OnFilterChanged", BindingFlags.Instance | BindingFlags.NonPublic);
			field_OnLatestPackageInfoFetched = CreateField("OnLatestPackageInfoFetched", BindingFlags.Instance | BindingFlags.NonPublic);
			field_OnUpdateTimeChange = CreateField<Action<string>>("OnUpdateTimeChange", BindingFlags.Instance | BindingFlags.NonPublic);
			field_projectDependencies = CreateField("projectDependencies", BindingFlags.Instance | BindingFlags.NonPublic);
			field_packages = CreateField("packages", BindingFlags.Static | BindingFlags.NonPublic);
			field_latestInfos = CreateField("latestInfos", BindingFlags.Static | BindingFlags.NonPublic);
			field_filter = CreateField("filter", BindingFlags.Instance | BindingFlags.NonPublic);
			field_lastUpdateTime = CreateField<string>("lastUpdateTime", BindingFlags.Instance | BindingFlags.NonPublic);
			field_listPackagesOffline = CreateField("listPackagesOffline", BindingFlags.Instance | BindingFlags.NonPublic);
			field_listPackages = CreateField("listPackages", BindingFlags.Instance | BindingFlags.NonPublic);
			field_searchPackages = CreateField("searchPackages", BindingFlags.Instance | BindingFlags.NonPublic);
			field_latestInfoListCache = CreateField("latestInfoListCache", BindingFlags.Instance | BindingFlags.NonPublic);
			field_packageErrors = CreateField("packageErrors", BindingFlags.Instance | BindingFlags.NonPublic);
			field_listPackagesVersion = CreateField<int>("listPackagesVersion", BindingFlags.Instance | BindingFlags.NonPublic);
			field_listPackagesOfflineVersion = CreateField<int>("listPackagesOfflineVersion", BindingFlags.Instance | BindingFlags.NonPublic);
			field_searchOperationOngoing = CreateField<bool>("searchOperationOngoing", BindingFlags.Instance | BindingFlags.Public);
			field_listOperationOngoing = CreateField<bool>("listOperationOngoing", BindingFlags.Instance | BindingFlags.Public);
			field_listOperationOfflineOngoing = CreateField<bool>("listOperationOfflineOngoing", BindingFlags.Instance | BindingFlags.Public);
			field_listOperationOffline = CreateField("listOperationOffline", BindingFlags.Instance | BindingFlags.NonPublic);
			field_listOperation = CreateField("listOperation", BindingFlags.Instance | BindingFlags.NonPublic);
			field_searchOperation = CreateField("searchOperation", BindingFlags.Instance | BindingFlags.NonPublic);
			field_SearchSignal = CreateField("SearchSignal", BindingFlags.Instance | BindingFlags.Public);
			field_ListSignal = CreateField("ListSignal", BindingFlags.Instance | BindingFlags.Public);
			property_ProjectDependencies = CreateProperty("ProjectDependencies", BindingFlags.Instance | BindingFlags.Public);
			property_Filter = CreateProperty("Filter", BindingFlags.Instance | BindingFlags.Public);
			property_CompletePackageInfosList = CreateProperty("CompletePackageInfosList", BindingFlags.Instance | BindingFlags.NonPublic);
			property_LatestListPackages = CreateProperty("LatestListPackages", BindingFlags.Instance | BindingFlags.Public);
			property_LatestSearchPackages = CreateProperty("LatestSearchPackages", BindingFlags.Instance | BindingFlags.Public);
			method_GetLatestInfoInCache_1 = CreateMethod("GetLatestInfoInCache", BindingFlags.Instance | BindingFlags.NonPublic, typeof(string));
			method_UpdateLatestInfoCache_1 = CreateMethod("UpdateLatestInfoCache", BindingFlags.Instance | BindingFlags.NonPublic, typeof(PackageInfo));
			method_SetFilter_1 = CreateMethod("SetFilter", BindingFlags.Instance | BindingFlags.Public, typeof(PackageFilter),typeof(bool));
			method_UpdatePackageCollection_1 = CreateMethod("UpdatePackageCollection", BindingFlags.Instance | BindingFlags.Public, typeof(bool));
			method_TriggerPackagesChanged_1 = CreateMethod("TriggerPackagesChanged", BindingFlags.Instance | BindingFlags.Public, null);
			method_FetchListOfflineCache_1 = CreateMethod("FetchListOfflineCache", BindingFlags.Instance | BindingFlags.NonPublic, typeof(bool));
			method_FetchListCache_1 = CreateMethod("FetchListCache", BindingFlags.Instance | BindingFlags.NonPublic, typeof(bool));
			method_FetchSearchCache_1 = CreateMethod("FetchSearchCache", BindingFlags.Instance | BindingFlags.NonPublic, typeof(bool));
			method_NeedsFetchLatest_1 = CreateMethod("NeedsFetchLatest", BindingFlags.Instance | BindingFlags.Public, typeof(PackageInfo));
			method_FetchLatestPackageInfo_1 = CreateMethod("FetchLatestPackageInfo", BindingFlags.Instance | BindingFlags.Public, typeof(PackageInfo),typeof(bool));
			method_UpdateListPackageInfosOffline_1 = CreateMethod("UpdateListPackageInfosOffline", BindingFlags.Instance | BindingFlags.NonPublic, typeof(IEnumerable<PackageInfo>),typeof(int));
			method_UpdateListPackageInfos_1 = CreateMethod("UpdateListPackageInfos", BindingFlags.Instance | BindingFlags.NonPublic, typeof(IEnumerable<PackageInfo>));
			method_UpdateSearchPackageInfos_1 = CreateMethod("UpdateSearchPackageInfos", BindingFlags.Instance | BindingFlags.NonPublic, typeof(IEnumerable<PackageInfo>));
			method_OrderedPackages_1 = CreateMethod("OrderedPackages", BindingFlags.Instance | BindingFlags.NonPublic, null);
			method_GetPackageByName_1 = CreateMethod("GetPackageByName", BindingFlags.Instance | BindingFlags.Public, typeof(string));
			method_GetPackage_1 = CreateMethod("GetPackage", BindingFlags.Instance | BindingFlags.Public, typeof(PackageInfo));
			method_GetPackageVersion_1 = CreateMethod("GetPackageVersion", BindingFlags.Instance | BindingFlags.Public, typeof(PackageInfo));
			method_GetPackageVersion_2 = CreateMethod("GetPackageVersion", BindingFlags.Instance | BindingFlags.Public, typeof(string));
			method_GetPackageError_1 = CreateMethod("GetPackageError", BindingFlags.Instance | BindingFlags.NonPublic, typeof(Package));
			method_AddPackageError_1 = CreateMethod("AddPackageError", BindingFlags.Instance | BindingFlags.Public, typeof(Package),typeof(Error));
			method_RemovePackageErrors_1 = CreateMethod("RemovePackageErrors", BindingFlags.Instance | BindingFlags.Public, typeof(Package));
			method_RebuildPackageDictionary_1 = CreateMethod("RebuildPackageDictionary", BindingFlags.Instance | BindingFlags.NonPublic, null);
			method_RebuildDependenciesDictionnary_1 = CreateMethod("RebuildDependenciesDictionnary", BindingFlags.Instance | BindingFlags.NonPublic, null);
		}
		partial void Initialize();
		/// <summary>
		/// Event type: System.Action<PackageFilter, IEnumerable<Package>>
		/// </summary>
		/// <returns>Delegate to be used for unsubscribing</returns>
		public Delegate SubscribeToOnPackagesChanged(Delegate @delegate)
		{
			return event_OnPackagesChanged.Subscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<PackageFilter, IEnumerable<Package>>
		/// </summary>
		public void UnsubscribeFromOnPackagesChanged(Delegate @delegate)
		{
			event_OnPackagesChanged.Unsubscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<PackageFilter>
		/// </summary>
		/// <returns>Delegate to be used for unsubscribing</returns>
		public Delegate SubscribeToOnFilterChanged(Delegate @delegate)
		{
			return event_OnFilterChanged.Subscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<PackageFilter>
		/// </summary>
		public void UnsubscribeFromOnFilterChanged(Delegate @delegate)
		{
			event_OnFilterChanged.Unsubscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<PackageInfo, bool>
		/// </summary>
		/// <returns>Delegate to be used for unsubscribing</returns>
		public Delegate SubscribeToOnLatestPackageInfoFetched(Delegate @delegate)
		{
			return event_OnLatestPackageInfoFetched.Subscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<PackageInfo, bool>
		/// </summary>
		public void UnsubscribeFromOnLatestPackageInfoFetched(Delegate @delegate)
		{
			event_OnLatestPackageInfoFetched.Unsubscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<string>
		/// </summary>
		/// <returns>Delegate to be used for unsubscribing</returns>
		public Delegate SubscribeToOnUpdateTimeChange(Delegate @delegate)
		{
			return event_OnUpdateTimeChange.Subscribe(@delegate);
		}
		/// <summary>
		/// Event type: System.Action<string>
		/// </summary>
		public void UnsubscribeFromOnUpdateTimeChange(Delegate @delegate)
		{
			event_OnUpdateTimeChange.Unsubscribe(@delegate);
		}
		public SemVersion EmbdeddedVersion
		{
			get
			{
				object _temp = field_EmbdeddedVersion.GetValue();
				return _temp == null ? null : new SemVersion(_temp);
			}
			set => field_EmbdeddedVersion.SetValue(value.Instance);
		}
		public SemVersion LocalVersion
		{
			get
			{
				object _temp = field_LocalVersion.GetValue();
				return _temp == null ? null : new SemVersion(_temp);
			}
			set => field_LocalVersion.SetValue(value.Instance);
		}
		public Action<string> OnUpdateTimeChange
		{
			get => field_OnUpdateTimeChange.GetValue();
			set => field_OnUpdateTimeChange.SetValue(value);
		}
		public Dictionary<string, SemVersion> projectDependencies
		{
			get
			{
				object _temp = field_projectDependencies.GetValue();
				return (Dictionary<string, SemVersion>) (_temp == null ? null : Utilities.GenerateDictionary<string,SemVersion>(_temp));
			}
		}
		public Dictionary<string, Package> packages
		{
			get
			{
				object _temp = field_packages.GetValue();
				return (Dictionary<string, Package>) (_temp == null ? null : Utilities.GenerateDictionary<string,Package>(_temp));
			}
		}
		public Dictionary<string, PackageInfo> latestInfos
		{
			get
			{
				object _temp = field_latestInfos.GetValue();
				return (Dictionary<string, PackageInfo>) (_temp == null ? null : Utilities.GenerateDictionary<string,PackageInfo>(_temp));
			}
		}
		public PackageFilter filter
		{
			get
			{
				object _temp = (int)field_filter.GetValue();
				return (PackageFilter)_temp;
			}
			set => field_filter.SetValue((int)value);
		}
		public string lastUpdateTime
		{
			get => field_lastUpdateTime.GetValue();
			set => field_lastUpdateTime.SetValue(value);
		}
		public List<PackageInfo> listPackagesOffline
		{
			get
			{
				object _temp = field_listPackagesOffline.GetValue();
				return (List<PackageInfo>) (_temp == null ? null : Utilities.GenerateEnumerable<PackageInfo>(_temp));
			}
		}
		public List<PackageInfo> listPackages
		{
			get
			{
				object _temp = field_listPackages.GetValue();
				return (List<PackageInfo>) (_temp == null ? null : Utilities.GenerateEnumerable<PackageInfo>(_temp));
			}
		}
		public List<PackageInfo> searchPackages
		{
			get
			{
				object _temp = field_searchPackages.GetValue();
				return (List<PackageInfo>) (_temp == null ? null : Utilities.GenerateEnumerable<PackageInfo>(_temp));
			}
		}
		public List<PackageInfo> latestInfoListCache
		{
			get
			{
				object _temp = field_latestInfoListCache.GetValue();
				return (List<PackageInfo>) (_temp == null ? null : Utilities.GenerateEnumerable<PackageInfo>(_temp));
			}
		}
		public List<PackageError> packageErrors
		{
			get
			{
				object _temp = field_packageErrors.GetValue();
				return (List<PackageError>) (_temp == null ? null : Utilities.GenerateEnumerable<PackageError>(_temp));
			}
		}
		public int listPackagesVersion
		{
			get => field_listPackagesVersion.GetValue();
			set => field_listPackagesVersion.SetValue(value);
		}
		public int listPackagesOfflineVersion
		{
			get => field_listPackagesOfflineVersion.GetValue();
			set => field_listPackagesOfflineVersion.SetValue(value);
		}
		public bool searchOperationOngoing
		{
			get => field_searchOperationOngoing.GetValue();
			set => field_searchOperationOngoing.SetValue(value);
		}
		public bool listOperationOngoing
		{
			get => field_listOperationOngoing.GetValue();
			set => field_listOperationOngoing.SetValue(value);
		}
		public bool listOperationOfflineOngoing
		{
			get => field_listOperationOfflineOngoing.GetValue();
			set => field_listOperationOfflineOngoing.SetValue(value);
		}
		public IListOperation listOperationOffline
		{
			get
			{
				object _temp = field_listOperationOffline.GetValue();
				return _temp == null ? null : new IListOperation(_temp);
			}
			set => field_listOperationOffline.SetValue(value.Instance);
		}
		public IListOperation listOperation
		{
			get
			{
				object _temp = field_listOperation.GetValue();
				return _temp == null ? null : new IListOperation(_temp);
			}
			set => field_listOperation.SetValue(value.Instance);
		}
		public ISearchOperation searchOperation
		{
			get
			{
				object _temp = field_searchOperation.GetValue();
				return _temp == null ? null : new ISearchOperation(_temp);
			}
			set => field_searchOperation.SetValue(value.Instance);
		}
		public Dictionary<string, SemVersion> ProjectDependencies
		{
			get
			{
				object _temp = property_ProjectDependencies.GetValue();
				return (Dictionary<string, SemVersion>) (_temp == null ? null : Utilities.GenerateDictionary<string,SemVersion>(_temp));
			}
		}
		public PackageFilter Filter
		{
			get
			{
				object _temp = (int)property_Filter.GetValue();
				return (PackageFilter)_temp;
			}
			set => property_Filter.SetValue((int)value);
		}
		public IEnumerable<PackageInfo> CompletePackageInfosList
		{
			get
			{
				object _temp = property_CompletePackageInfosList.GetValue();
				return (IEnumerable<PackageInfo>) (_temp == null ? null : Utilities.GenerateEnumerable<PackageInfo>(_temp));
			}
		}
		public IEnumerable<PackageInfo> LatestListPackages
		{
			get
			{
				object _temp = property_LatestListPackages.GetValue();
				return (IEnumerable<PackageInfo>) (_temp == null ? null : Utilities.GenerateEnumerable<PackageInfo>(_temp));
			}
		}
		public IEnumerable<PackageInfo> LatestSearchPackages
		{
			get
			{
				object _temp = property_LatestSearchPackages.GetValue();
				return (IEnumerable<PackageInfo>) (_temp == null ? null : Utilities.GenerateEnumerable<PackageInfo>(_temp));
			}
		}
		public PackageInfo GetLatestInfoInCache(string packageId)
		{
			return new PackageInfo(method_GetLatestInfoInCache_1.Invoke(packageId));
		}
		public void UpdateLatestInfoCache(PackageInfo info)
		{
			method_UpdateLatestInfoCache_1.Invoke(info);
		}
		public bool SetFilter(PackageFilter value,bool refresh)
		{
			return (bool) method_SetFilter_1.Invoke((int)value,refresh);
		}
		public void UpdatePackageCollection(bool rebuildDictionary)
		{
			method_UpdatePackageCollection_1.Invoke(rebuildDictionary);
		}
		public void TriggerPackagesChanged()
		{
			method_TriggerPackagesChanged_1.Invoke();
		}
		public void FetchListOfflineCache(bool forceRefetch)
		{
			method_FetchListOfflineCache_1.Invoke(forceRefetch);
		}
		public void FetchListCache(bool forceRefetch)
		{
			method_FetchListCache_1.Invoke(forceRefetch);
		}
		public void FetchSearchCache(bool forceRefetch)
		{
			method_FetchSearchCache_1.Invoke(forceRefetch);
		}
		public bool NeedsFetchLatest(PackageInfo packageInfo)
		{
			return (bool) method_NeedsFetchLatest_1.Invoke(packageInfo);
		}
		public void FetchLatestPackageInfo(PackageInfo packageInfo,bool isDefaultVersion)
		{
			method_FetchLatestPackageInfo_1.Invoke(packageInfo,isDefaultVersion);
		}
		public void UpdateListPackageInfosOffline(IEnumerable<PackageInfo> newInfos,int version)
		{
			method_UpdateListPackageInfosOffline_1.Invoke(newInfos,version);
		}
		public void UpdateListPackageInfos(IEnumerable<PackageInfo> newInfos)
		{
			method_UpdateListPackageInfos_1.Invoke(newInfos);
		}
		public void UpdateSearchPackageInfos(IEnumerable<PackageInfo> newInfos)
		{
			method_UpdateSearchPackageInfos_1.Invoke(newInfos);
		}
		public IEnumerable<Package> OrderedPackages()
		{
			return Utilities.GenerateEnumerable<Package>(method_OrderedPackages_1.Invoke());
		}
		public Package GetPackageByName(string name)
		{
			return new Package(method_GetPackageByName_1.Invoke(name));
		}
		public Package GetPackage(PackageInfo packageInfo)
		{
			return new Package(method_GetPackage_1.Invoke(packageInfo));
		}
		public PackageVersion GetPackageVersion(PackageInfo packageInfo)
		{
			return new PackageVersion(method_GetPackageVersion_1.Invoke(packageInfo));
		}
		public PackageVersion GetPackageVersion(string packageId)
		{
			return new PackageVersion(method_GetPackageVersion_2.Invoke(packageId));
		}
		public Error GetPackageError(Package package)
		{
			return (Error) method_GetPackageError_1.Invoke(package);
		}
		public void AddPackageError(Package package,Error error)
		{
			method_AddPackageError_1.Invoke(package,error);
		}
		public void RemovePackageErrors(Package package)
		{
			method_RemovePackageErrors_1.Invoke(package);
		}
		public void RebuildPackageDictionary()
		{
			method_RebuildPackageDictionary_1.Invoke();
		}
		public void RebuildDependenciesDictionnary()
		{
			method_RebuildDependenciesDictionnary_1.Invoke();
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.PackageManager.UI.PackageCollection, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
