// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.PackageManager.UI.PackageInfo, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.UI;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class PackageInfo : ReflectiveClass
	{
		private ReflectiveField<string> field_builtinPackageDocsUrlKey;
		private ReflectiveField<string> field_Name;
		private ReflectiveField<string> field_DisplayName;
		private ReflectiveField<string> field_PackageId;
		private ReflectiveField<string> field_Version;
		private ReflectiveField<string> field_Description;
		private ReflectiveField<string> field_Category;
		private ReflectiveField field_State;
		private ReflectiveField<bool> field_IsCurrent;
		private ReflectiveField<bool> field_IsLatest;
		private ReflectiveField<string> field_Group;
		private ReflectiveField<string> field_Type;
		private ReflectiveField<PackageSource> field_Origin;
		private ReflectiveField<List<Error>> field_Errors;
		private ReflectiveField<bool> field_IsVerified;
		private ReflectiveField<string> field_Author;
		private ReflectiveField<List<Sample>> field_Samples;
		private ReflectiveField<bool> field_HasFullFetch;
		private ReflectiveField<PackageInfo> field_Info;
		private ReflectiveProperty<string> property_PackageId;
		private ReflectiveProperty<string> property_VersionId;
		private ReflectiveProperty<string> property_ShortVersionId;
		private ReflectiveProperty<string> property_BuiltInDescription;
		private ReflectiveProperty<bool> property_RedirectsToManual;
		private ReflectiveProperty<bool> property_HasChangelog;
		private ReflectiveProperty<bool> property_IsPreRelease;
		private ReflectiveProperty<bool> property_IsPreview;
		private ReflectiveProperty<bool> property_IsUserVisible;
		private ReflectiveProperty<bool> property_IsInDevelopment;
		private ReflectiveProperty<bool> property_IsLocal;
		private ReflectiveProperty<bool> property_IsGit;
		private ReflectiveProperty<bool> property_IsBuiltIn;
		private ReflectiveProperty<bool> property_IsCore;
		private ReflectiveProperty<bool> property_IsAvailableOffline;
		private ReflectiveProperty<string> property_VersionWithoutTag;
		private ReflectiveProperty<bool> property_IsVersionLocked;
		private ReflectiveProperty<bool> property_CanBeRemoved;
		private ReflectiveMethod method_ParseShortVersion_1;
		private ReflectiveMethod method_GetPackageUrlRedirect_1;
		private ReflectiveMethod method_GetDocumentationUrl_1;
		private ReflectiveMethod method_GetOfflineDocumentationUrl_1;
		private ReflectiveMethod method_GetChangelogUrl_1;
		private ReflectiveMethod method_GetOfflineChangelogUrl_1;
		private ReflectiveMethod method_GetLicensesUrl_1;
		private ReflectiveMethod method_GetOfflineLicensesUrl_1;
		private ReflectiveMethod method_Equals_1;
		private ReflectiveMethod method_GetHashCode_1;
		private ReflectiveMethod method_HasVersionTag_1;
		private ReflectiveMethod method_HasVersionTag_2;
		private ReflectiveMethod method_IsPackageBuiltIn_1;
		private ReflectiveMethod method_OnBeforeSerialize_1;
		private ReflectiveMethod method_OnAfterDeserialize_1;
		private ReflectiveMethod method_Consolidate_1;
		private ReflectiveMethod method_StandardizedLabel_1;
		public PackageInfo(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public PackageInfo(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			field_builtinPackageDocsUrlKey = CreateField<string>("builtinPackageDocsUrlKey", BindingFlags.Static | BindingFlags.NonPublic);
			field_Name = CreateField<string>("Name", BindingFlags.Instance | BindingFlags.Public);
			field_DisplayName = CreateField<string>("DisplayName", BindingFlags.Instance | BindingFlags.Public);
			field_PackageId = CreateField<string>("PackageId", BindingFlags.Instance | BindingFlags.NonPublic);
			field_Version = CreateField<string>("Version", BindingFlags.Instance | BindingFlags.NonPublic);
			field_Description = CreateField<string>("Description", BindingFlags.Instance | BindingFlags.Public);
			field_Category = CreateField<string>("Category", BindingFlags.Instance | BindingFlags.Public);
			field_State = CreateField("State", BindingFlags.Instance | BindingFlags.Public);
			field_IsCurrent = CreateField<bool>("IsCurrent", BindingFlags.Instance | BindingFlags.Public);
			field_IsLatest = CreateField<bool>("IsLatest", BindingFlags.Instance | BindingFlags.Public);
			field_Group = CreateField<string>("Group", BindingFlags.Instance | BindingFlags.Public);
			field_Type = CreateField<string>("Type", BindingFlags.Instance | BindingFlags.Public);
			field_Origin = CreateField<PackageSource>("Origin", BindingFlags.Instance | BindingFlags.Public);
			field_Errors = CreateField<List<Error>>("Errors", BindingFlags.Instance | BindingFlags.Public);
			field_IsVerified = CreateField<bool>("IsVerified", BindingFlags.Instance | BindingFlags.Public);
			field_Author = CreateField<string>("Author", BindingFlags.Instance | BindingFlags.Public);
			field_Samples = CreateField<List<Sample>>("Samples", BindingFlags.Instance | BindingFlags.Public);
			field_HasFullFetch = CreateField<bool>("HasFullFetch", BindingFlags.Instance | BindingFlags.Public);
			field_Info = CreateField<PackageInfo>("Info", BindingFlags.Instance | BindingFlags.Public);
			property_PackageId = CreateProperty<string>("PackageId", BindingFlags.Instance | BindingFlags.Public);
			property_VersionId = CreateProperty<string>("VersionId", BindingFlags.Instance | BindingFlags.Public);
			property_ShortVersionId = CreateProperty<string>("ShortVersionId", BindingFlags.Instance | BindingFlags.Public);
			property_BuiltInDescription = CreateProperty<string>("BuiltInDescription", BindingFlags.Instance | BindingFlags.Public);
			property_RedirectsToManual = CreateProperty<bool>("RedirectsToManual", BindingFlags.Instance | BindingFlags.Public);
			property_HasChangelog = CreateProperty<bool>("HasChangelog", BindingFlags.Instance | BindingFlags.Public);
			property_IsPreRelease = CreateProperty<bool>("IsPreRelease", BindingFlags.Instance | BindingFlags.Public);
			property_IsPreview = CreateProperty<bool>("IsPreview", BindingFlags.Instance | BindingFlags.Public);
			property_IsUserVisible = CreateProperty<bool>("IsUserVisible", BindingFlags.Instance | BindingFlags.Public);
			property_IsInDevelopment = CreateProperty<bool>("IsInDevelopment", BindingFlags.Instance | BindingFlags.Public);
			property_IsLocal = CreateProperty<bool>("IsLocal", BindingFlags.Instance | BindingFlags.Public);
			property_IsGit = CreateProperty<bool>("IsGit", BindingFlags.Instance | BindingFlags.Public);
			property_IsBuiltIn = CreateProperty<bool>("IsBuiltIn", BindingFlags.Instance | BindingFlags.Public);
			property_IsCore = CreateProperty<bool>("IsCore", BindingFlags.Instance | BindingFlags.Public);
			property_IsAvailableOffline = CreateProperty<bool>("IsAvailableOffline", BindingFlags.Instance | BindingFlags.Public);
			property_VersionWithoutTag = CreateProperty<string>("VersionWithoutTag", BindingFlags.Instance | BindingFlags.Public);
			property_IsVersionLocked = CreateProperty<bool>("IsVersionLocked", BindingFlags.Instance | BindingFlags.Public);
			property_CanBeRemoved = CreateProperty<bool>("CanBeRemoved", BindingFlags.Instance | BindingFlags.Public);
			method_ParseShortVersion_1 = CreateMethod("ParseShortVersion", BindingFlags.Static | BindingFlags.NonPublic, typeof(string));
			method_GetPackageUrlRedirect_1 = CreateMethod("GetPackageUrlRedirect", BindingFlags.Static | BindingFlags.Public, typeof(string),typeof(string));
			method_GetDocumentationUrl_1 = CreateMethod("GetDocumentationUrl", BindingFlags.Instance | BindingFlags.Public, typeof(bool));
			method_GetOfflineDocumentationUrl_1 = CreateMethod("GetOfflineDocumentationUrl", BindingFlags.Instance | BindingFlags.NonPublic, null);
			method_GetChangelogUrl_1 = CreateMethod("GetChangelogUrl", BindingFlags.Instance | BindingFlags.Public, typeof(bool));
			method_GetOfflineChangelogUrl_1 = CreateMethod("GetOfflineChangelogUrl", BindingFlags.Instance | BindingFlags.NonPublic, null);
			method_GetLicensesUrl_1 = CreateMethod("GetLicensesUrl", BindingFlags.Instance | BindingFlags.Public, typeof(bool));
			method_GetOfflineLicensesUrl_1 = CreateMethod("GetOfflineLicensesUrl", BindingFlags.Instance | BindingFlags.NonPublic, null);
			method_Equals_1 = CreateMethod("Equals", BindingFlags.Instance | BindingFlags.Public, typeof(PackageInfo));
			method_GetHashCode_1 = CreateMethod("GetHashCode", BindingFlags.Instance | BindingFlags.Public, null);
			method_HasVersionTag_1 = CreateMethod("HasVersionTag", BindingFlags.Instance | BindingFlags.Public, typeof(string));
			method_HasVersionTag_2 = CreateMethod("HasVersionTag", BindingFlags.Instance | BindingFlags.Public, typeof(PackageTag));
			method_IsPackageBuiltIn_1 = CreateMethod("IsPackageBuiltIn", BindingFlags.Static | BindingFlags.Public, typeof(PackageSource),typeof(string));
			method_OnBeforeSerialize_1 = CreateMethod("OnBeforeSerialize", BindingFlags.Instance | BindingFlags.Public, null);
			method_OnAfterDeserialize_1 = CreateMethod("OnAfterDeserialize", BindingFlags.Instance | BindingFlags.Public, null);
			method_Consolidate_1 = CreateMethod("Consolidate", BindingFlags.Instance | BindingFlags.Public, typeof(PackageInfo));
			method_StandardizedLabel_1 = CreateMethod("StandardizedLabel", BindingFlags.Instance | BindingFlags.Public, typeof(bool));
		}
		partial void Initialize();
		public string builtinPackageDocsUrlKey
		{
			get => field_builtinPackageDocsUrlKey.GetValue();
			set => field_builtinPackageDocsUrlKey.SetValue(value);
		}
		public string Name
		{
			get => field_Name.GetValue();
			set => field_Name.SetValue(value);
		}
		public string DisplayName
		{
			get => field_DisplayName.GetValue();
			set => field_DisplayName.SetValue(value);
		}
		public string Version
		{
			get => field_Version.GetValue();
			set => field_Version.SetValue(value);
		}
		public string Description
		{
			get => field_Description.GetValue();
			set => field_Description.SetValue(value);
		}
		public string Category
		{
			get => field_Category.GetValue();
			set => field_Category.SetValue(value);
		}
		public PackageState State
		{
			get
			{
				object _temp = (int)field_State.GetValue();
				return (PackageState)_temp;
			}
			set => field_State.SetValue((int)value);
		}
		public bool IsCurrent
		{
			get => field_IsCurrent.GetValue();
			set => field_IsCurrent.SetValue(value);
		}
		public bool IsLatest
		{
			get => field_IsLatest.GetValue();
			set => field_IsLatest.SetValue(value);
		}
		public string Group
		{
			get => field_Group.GetValue();
			set => field_Group.SetValue(value);
		}
		public string Type
		{
			get => field_Type.GetValue();
			set => field_Type.SetValue(value);
		}
		public PackageSource Origin
		{
			get => field_Origin.GetValue();
			set => field_Origin.SetValue(value);
		}
		public List<Error> Errors
		{
			get => field_Errors.GetValue();
			set => field_Errors.SetValue(value);
		}
		public bool IsVerified
		{
			get => field_IsVerified.GetValue();
			set => field_IsVerified.SetValue(value);
		}
		public string Author
		{
			get => field_Author.GetValue();
			set => field_Author.SetValue(value);
		}
		public List<Sample> Samples
		{
			get => field_Samples.GetValue();
			set => field_Samples.SetValue(value);
		}
		public bool HasFullFetch
		{
			get => field_HasFullFetch.GetValue();
			set => field_HasFullFetch.SetValue(value);
		}
		public PackageInfo Info
		{
			get => field_Info.GetValue();
			set => field_Info.SetValue(value);
		}
		public string PackageId
		{
			get => property_PackageId.GetValue();
			set => property_PackageId.SetValue(value);
		}
		public string VersionId
		{
			get => property_VersionId.GetValue();
		}
		public string ShortVersionId
		{
			get => property_ShortVersionId.GetValue();
		}
		public string BuiltInDescription
		{
			get => property_BuiltInDescription.GetValue();
		}
		public bool RedirectsToManual
		{
			get => property_RedirectsToManual.GetValue();
		}
		public bool HasChangelog
		{
			get => property_HasChangelog.GetValue();
		}
		public bool IsPreRelease
		{
			get => property_IsPreRelease.GetValue();
		}
		public bool IsPreview
		{
			get => property_IsPreview.GetValue();
		}
		public bool IsUserVisible
		{
			get => property_IsUserVisible.GetValue();
		}
		public bool IsInDevelopment
		{
			get => property_IsInDevelopment.GetValue();
		}
		public bool IsLocal
		{
			get => property_IsLocal.GetValue();
		}
		public bool IsGit
		{
			get => property_IsGit.GetValue();
		}
		public bool IsBuiltIn
		{
			get => property_IsBuiltIn.GetValue();
		}
		public bool IsCore
		{
			get => property_IsCore.GetValue();
		}
		public bool IsAvailableOffline
		{
			get => property_IsAvailableOffline.GetValue();
		}
		public string VersionWithoutTag
		{
			get => property_VersionWithoutTag.GetValue();
		}
		public bool IsVersionLocked
		{
			get => property_IsVersionLocked.GetValue();
		}
		public bool CanBeRemoved
		{
			get => property_CanBeRemoved.GetValue();
		}
		public Version ParseShortVersion(string shortVersionId)
		{
			return (Version) method_ParseShortVersion_1.Invoke(shortVersionId);
		}
		public string GetPackageUrlRedirect(string packageName,string shortVersionId)
		{
			return (string) method_GetPackageUrlRedirect_1.Invoke(packageName,shortVersionId);
		}
		public string GetDocumentationUrl(bool offline)
		{
			return (string) method_GetDocumentationUrl_1.Invoke(offline);
		}
		public string GetOfflineDocumentationUrl()
		{
			return (string) method_GetOfflineDocumentationUrl_1.Invoke();
		}
		public string GetChangelogUrl(bool offline)
		{
			return (string) method_GetChangelogUrl_1.Invoke(offline);
		}
		public string GetOfflineChangelogUrl()
		{
			return (string) method_GetOfflineChangelogUrl_1.Invoke();
		}
		public string GetLicensesUrl(bool offline)
		{
			return (string) method_GetLicensesUrl_1.Invoke(offline);
		}
		public string GetOfflineLicensesUrl()
		{
			return (string) method_GetOfflineLicensesUrl_1.Invoke();
		}
		public bool Equals(PackageInfo other)
		{
			return (bool) method_Equals_1.Invoke(other);
		}
		public int GetHashCode()
		{
			return (int) method_GetHashCode_1.Invoke();
		}
		public bool HasVersionTag(string tag)
		{
			return (bool) method_HasVersionTag_1.Invoke(tag);
		}
		public bool HasVersionTag(PackageTag tag)
		{
			return (bool) method_HasVersionTag_2.Invoke((int)tag);
		}
		public bool IsPackageBuiltIn(PackageSource source,string type)
		{
			return (bool) method_IsPackageBuiltIn_1.Invoke((int)source,type);
		}
		public void OnBeforeSerialize()
		{
			method_OnBeforeSerialize_1.Invoke();
		}
		public void OnAfterDeserialize()
		{
			method_OnAfterDeserialize_1.Invoke();
		}
		public void Consolidate(PackageInfo other)
		{
			method_Consolidate_1.Invoke(other);
		}
		public string StandardizedLabel(bool showSimplified)
		{
			return (string) method_StandardizedLabel_1.Invoke(showSimplified);
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.PackageManager.UI.PackageInfo, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
