// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.PackageManager.UI.IListOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
using System.Collections.Generic;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class IListOperation : ReflectiveClass
	{
		private ReflectiveProperty<bool> property_OfflineMode;
		private ReflectiveMethod method_GetPackageListAsync_1;
		public IListOperation(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public IListOperation(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			property_OfflineMode = CreateProperty<bool>("OfflineMode", BindingFlags.Instance | BindingFlags.Public);
			method_GetPackageListAsync_1 = CreateMethod("GetPackageListAsync", BindingFlags.Instance | BindingFlags.Public, typeof(Action<IEnumerable<PackageInfo>>),typeof(Action<Error>));
		}
		partial void Initialize();
		public bool OfflineMode
		{
			get => property_OfflineMode.GetValue();
			set => property_OfflineMode.SetValue(value);
		}
		public void GetPackageListAsync(Action<IEnumerable<PackageInfo>> doneCallbackAction,Action<Error> errorCallbackAction)
		{
			method_GetPackageListAsync_1.Invoke(doneCallbackAction,errorCallbackAction);
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.PackageManager.UI.IListOperation, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
