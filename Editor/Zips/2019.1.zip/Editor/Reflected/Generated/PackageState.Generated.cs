namespace TNRD.PackageManager.Reflected
{
	public enum PackageState : int
	{
		UpToDate=0,
		Outdated=1,
		InProgress=2,
		Error=3
	}
}
