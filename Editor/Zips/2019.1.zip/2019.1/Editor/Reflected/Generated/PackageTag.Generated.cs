namespace TNRD.PackageManager.Reflected
{
	public enum PackageTag : int
	{
		builtin=0,
		preview=1,
		verified=2,
		inDevelopment=3,
		local=4,
		git=5
	}
}
