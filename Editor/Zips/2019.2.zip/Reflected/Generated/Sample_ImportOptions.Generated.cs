namespace TNRD.PackageManager.Reflected
{
	public enum Sample_ImportOptions : int
	{
		None=0,
		OverridePreviousImports=1,
		HideImportWindow=2
	}
}
