namespace TNRD.PackageManager.Reflected
{
	public enum PackageType : int
	{
		module=0,
		package=1,
		template=2
	}
}
