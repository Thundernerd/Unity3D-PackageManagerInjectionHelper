namespace TNRD.PackageManager.Reflected
{
	public enum PackageStatus : int
	{
		Unknown=0,
		Unavailable=1,
		InProgress=2,
		Error=3,
		Available=4
	}
}
