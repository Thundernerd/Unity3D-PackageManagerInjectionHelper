namespace TNRD.PackageManager.Reflected
{
	public enum PackageGroupOrigins : int
	{
		Packages=0,
		BuiltInPackages=1
	}
}
