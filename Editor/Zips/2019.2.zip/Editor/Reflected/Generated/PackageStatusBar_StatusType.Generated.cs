namespace TNRD.PackageManager.Reflected
{
	public enum PackageStatusBar_StatusType : int
	{
		Normal=0,
		Loading=1,
		Error=2
	}
}
