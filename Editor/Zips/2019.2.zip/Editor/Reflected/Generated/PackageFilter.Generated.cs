namespace TNRD.PackageManager.Reflected
{
	public enum PackageFilter : int
	{
		All=0,
		Local=1,
		Modules=2
	}
}
