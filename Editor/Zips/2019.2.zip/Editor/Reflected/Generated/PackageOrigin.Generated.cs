namespace TNRD.PackageManager.Reflected
{
	public enum PackageOrigin : int
	{
		Unknown=0,
		Builtin=1,
		Registry=2
	}
}
