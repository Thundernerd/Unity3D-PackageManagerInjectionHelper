namespace TNRD.PackageManager.Reflected
{
	public enum PackageDetails_PackageAction : int
	{
		Add=0,
		Remove=1,
		Update=2,
		Enable=3,
		Disable=4,
		UpToDate=5,
		Current=6,
		Local=7,
		Git=8,
		Embedded=9,
		Download=10,
		Upgrade=11,
		Import=12
	}
}
