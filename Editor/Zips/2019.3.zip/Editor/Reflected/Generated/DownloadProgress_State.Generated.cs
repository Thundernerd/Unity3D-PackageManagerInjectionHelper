namespace TNRD.PackageManager.Reflected
{
	public enum DownloadProgress_State : int
	{
		Started=0,
		InProgress=1,
		Completed=2,
		Decrypting=3,
		Aborted=4,
		Error=5
	}
}
