// -------------------------------------------------------------------
// 			AUTO-GENERATED
//
// 	Original:
// 	UnityEditor.PackageManager.UI.PageManager, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null
// -------------------------------------------------------------------
using System;
using System.Reflection;
using TNRD.Reflectives;
using UnityEditor.PackageManager;
using UnityEditor.PackageManager.UI;
namespace TNRD.PackageManager.Reflected
{
	public sealed partial class PageManager : ReflectiveClass
	{
		private ReflectiveField field_sInstance;
		private ReflectiveField<int> field_kDefaultPageSize;
		private ReflectiveProperty property_instance;
		public PageManager(object instance) : base(instance)
		{
			Construct();
			Initialize();
		}
		public PageManager(Type type) : base(type)
		{
			Construct();
			Initialize();
		}
		private void Construct()
		{
			field_sInstance = CreateField("sInstance", BindingFlags.Static | BindingFlags.NonPublic);
			field_kDefaultPageSize = CreateField<int>("kDefaultPageSize", BindingFlags.Static | BindingFlags.Public);
			property_instance = CreateProperty("instance", BindingFlags.Static | BindingFlags.Public);
		}
		partial void Initialize();
		public IPageManager sInstance
		{
			get
			{
				object _temp = field_sInstance.GetValue();
				return _temp == null ? null : new IPageManager(_temp);
			}
			set => field_sInstance.SetValue(value.Instance);
		}
		public int kDefaultPageSize
		{
			get => field_kDefaultPageSize.GetValue();
			set => field_kDefaultPageSize.SetValue(value);
		}
		public IPageManager instance
		{
			get
			{
				object _temp = property_instance.GetValue();
				return _temp == null ? null : new IPageManager(_temp);
			}
		}
		public static Type GetOriginalType()
		{
			return System.Type.GetType("UnityEditor.PackageManager.UI.PageManager, UnityEditor, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null");
		}
	}
}
