namespace TNRD.PackageManager.Reflected
{
	public enum PackageFilterTab : int
	{
		All=0,
		Local=1,
		Modules=2,
		AssetStore=3,
		InDevelopment=4
	}
}
