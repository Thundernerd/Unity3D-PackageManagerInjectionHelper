namespace TNRD.PackageManager.Reflected
{
	public enum PackageImage_ImageType : int
	{
		Main=0,
		Screenshot=1,
		Sketchfab=2,
		Youtube=3
	}
}
