namespace TNRD.PackageManager.Reflected
{
    public sealed partial class PackageDatabase
    {
        /// <summary>
        /// Creates a static instance of the Package Database
        /// </summary>
        /// <returns></returns>
        public static IPackageDatabase GetInstance()
        {
            PackageDatabase packageDatabase = new PackageDatabase(GetOriginalType());
            return packageDatabase.instance;
        }
    }
}