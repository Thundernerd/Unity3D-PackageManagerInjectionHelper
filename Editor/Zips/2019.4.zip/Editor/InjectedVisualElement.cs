using System;
using JetBrains.Annotations;
using TNRD.Events;
using TNRD.PackageManager.Reflected;
using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace TNRD.PackageManager
{
    /// <summary>
    /// A visual element that gets added to the Package Manager Window through an IPackageManagerExtension
    /// </summary>
    [PublicAPI]
    public class InjectedVisualElement : VisualElement
    {
        private bool isAttachedToPanel;
        internal bool IsInitialized;
        private SafeEvent initialized;

        internal event Action Initialized
        {
            add => initialized += value;
            remove => initialized -= value;
        }

        private bool IsValid => Root != null && isAttachedToPanel;

        /// <summary>
        /// The root Visual Element of the Package Manager Window
        /// </summary>
        [PublicAPI]
        public VisualElement Root
        {
            get
            {
                VisualElement root = this;

                while (root.parent != null)
                {
                    root = root.parent;
                }

                return root;
            }
        }

        /// <summary>
        /// Reflected Package Manager Toolbar section of the Package Manager Window
        /// </summary>
        [PublicAPI]
        public PackageManagerToolbar PackageManagerToolbar => !IsValid ? null : new PackageManagerToolbar(Root.Q("topMenuToolbar"));

        /// <summary>
        /// Reflected Package List section of the Package Manager Window
        /// </summary>
        [PublicAPI]
        public PackageList PackageList => !IsValid ? null : new PackageList(Root.Q("packageList"));

        /// <summary>
        /// Reflected Package Status Bar section of the Package Manager Window
        /// </summary>
        [PublicAPI]
        public PackageStatusBar PackageStatusBar => !IsValid ? null : new PackageStatusBar(Root.Q("packageStatusBar"));

        /// <summary>
        /// Reflected Package Details section of the Package Manager Window
        /// </summary>
        [PublicAPI]
        public PackageDetails PackageDetails => !IsValid ? null : new PackageDetails(Root.Q("packageDetails"));

        /// <summary>
        /// Reflected Package Toolbar section of the Package Manager Window
        /// </summary>
        [PublicAPI]
        public PackageToolbar PackageToolbar => !IsValid ? null : new PackageToolbar(Root.Q("packageToolbar"));

        public InjectedVisualElement()
        {
            EditorApplication.delayCall += Initialize;

            RegisterCallback<AttachToPanelEvent>(OnAttachedToPanel);
            RegisterCallback<DetachFromPanelEvent>(OnDetachedFromPanel);
        }

        private void OnAttachedToPanel(AttachToPanelEvent evt)
        {
            isAttachedToPanel = true;
        }

        private void OnDetachedFromPanel(DetachFromPanelEvent evt)
        {
            isAttachedToPanel = false;
            UnregisterCallback<AttachToPanelEvent>(OnAttachedToPanel);
            UnregisterCallback<DetachFromPanelEvent>(OnDetachedFromPanel);
        }

        private void Initialize()
        {
            initialized.Invoke();
            IsInitialized = true;
        }
    }
}