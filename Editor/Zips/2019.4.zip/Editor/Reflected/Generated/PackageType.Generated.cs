namespace TNRD.PackageManager.Reflected
{
	public enum PackageType : int
	{
		None=0,
		Installable=1,
		BuiltIn=2,
		AssetStore=4,
		Unity=8,
		ScopedRegistry=16
	}
}
