namespace TNRD.PackageManager.Reflected
{
	public enum PackageProgress : int
	{
		None=0,
		Refreshing=1,
		Downloading=2,
		Installing=3,
		Removing=4
	}
}
