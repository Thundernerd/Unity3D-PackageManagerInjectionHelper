namespace TNRD.PackageManager.Reflected
{
	public enum EntitlementLicenseType : int
	{
		Public=0,
		AssetStore=1,
		Enterprise=2
	}
}
